function selectOption(option) {
  if (option === 'takeout') {
    alert('테이크 아웃을 선택하셨습니다.');
    location.href = 'index.html';
  } else if (option === 'eat-in') {
    alert('매장에서 먹기를 선택하셨습니다.');
    location.href = 'index.html';
  }
}
