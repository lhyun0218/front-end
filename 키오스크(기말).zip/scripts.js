let cartItems = []; // 장바구니 항목을 저장하는 배열
let salesReport = JSON.parse(localStorage.getItem("salesReport")) || []; // 판매 내역 (localStorage에서 로드)
let totalSales = parseInt(localStorage.getItem("totalSales")) || 0; // 총 판매 금액 (localStorage에서 로드)

let menuItems = [
  { id: 1, name: "에스프레소", price: 2500, image: "es.png" },
  { id: 2, name: "아메리카노", price: 2500, image: "coffee.jpg" },
  { id: 3, name: "카푸치노", price: 4500, image: "ca.png" },
  { id: 4, name: "카페라떼", price: 4500, image: "cafelatte.jpg" },
  { id: 5, name: "바닐라라떼", price: 4500, image: "va.jpg" },
  { id: 6, name: "카라멜마끼아또", price: 4500, image: "ma.png" },
  { id: 7, name: "헤이즐넛라떼", price: 4500, image: "he.png" },
  { id: 8, name: "카페모카", price: 4500, image: "moka.jpg" },
  { id: 9, name: "돌체라떼", price: 4500, image: "dol.png" },
  { id: 10, name: "초콜릿 케이크", price: 5000, image: "cake.jpg" },
  { id: 11, name: "블루베리 머핀", price: 3500, image: "blm.jpg" },
];

// 페이지당 메뉴 항목 수
const itemsPerPage = 6; // 1페이지에 6개 상품 표시
let currentPage = 0;

// 메뉴 항목을 페이지별로 나누기
function paginateMenu() {
  const start = currentPage * itemsPerPage;
  const end = start + itemsPerPage;
  return menuItems.slice(start, end);
}

// 메뉴 표시 함수
function displayMenu() {
  const menuContainer = document.getElementById("menu-container");
  menuContainer.innerHTML = ""; // 기존 메뉴 내용 제거

  const currentMenuItems = paginateMenu();

  currentMenuItems.forEach(item => {
    const div = document.createElement("div");
    div.className = "item";
    div.id = item.id; // 각 메뉴 항목에 id 속성 추가
    div.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <p>${item.name}</p>
      <p>${item.price}원</p>
      <button onclick="addToCart(${item.id})">추가</button>
    `;
    menuContainer.appendChild(div);
  });

  makeItemsDraggable();
}

// 페이지 전환 함수 (이전, 다음 버튼)
document.getElementById("prev-menu-button").onclick = () => {
  if (currentPage > 0) {
    currentPage--;
    fadeMenuTransition();
  }
};

document.getElementById("next-menu-button").onclick = () => {
  if ((currentPage + 1) * itemsPerPage < menuItems.length) {
    currentPage++;
    fadeMenuTransition();
  }
};

// 메뉴 전환 시 페이드 애니메이션
function fadeMenuTransition() {
  const menuContainer = document.getElementById("menu-container");
  menuContainer.classList.add("fade-out");
  
  setTimeout(() => {
    displayMenu();
    menuContainer.classList.remove("fade-out");
  }, 300); // 애니메이션 지속 시간
}

// 장바구니에 추가하는 함수
function addToCart(id) {
  const item = menuItems.find(menu => menu.id === id);
  if (!item) return;

  // 장바구니에 항목이 이미 있는지 확인
  const cartItem = cartItems.find(cart => cart.id === id);
  if (cartItem) {
    cartItem.quantity++;
  } else {
    cartItems.push({ ...item, quantity: 1 });
  }

  displayCart();
}

// 장바구니 표시 함수
function displayCart() {
  const cartContainer = document.getElementById("cart-container");
  cartContainer.innerHTML = "";  // 장바구니 내용을 새로 고침
  let totalPrice = 0;

  // 장바구니 항목을 화면에 표시
  cartItems.forEach(item => {
    totalPrice += item.price * item.quantity;
    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = `
      <p>${item.name}</p>
      <p>${item.price}원 x ${item.quantity}</p>
      <button onclick="changeQuantity(${item.id}, 1)">+</button>
      <button onclick="changeQuantity(${item.id}, -1)">-</button>
      <button class="remove-button" onclick="removeFromCart(${item.id})">제거</button>
    `;
    cartContainer.appendChild(div);
  });

  // 총합 표시
  document.getElementById("total-price").textContent = totalPrice;
}

// 장바구니에서 제거하는 함수
function removeFromCart(id) {
  cartItems = cartItems.filter(cart => cart.id !== id);
  displayCart();
}

// 수량 변경 함수
function changeQuantity(id, delta) {
  const cartItem = cartItems.find(cart => cart.id === id);
  if (!cartItem) return;

  cartItem.quantity += delta;
  if (cartItem.quantity <= 0) removeFromCart(id);
  displayCart();
}

// 결제 처리 함수
function checkout() {
  if (cartItems.length === 0) {
    alert("장바구니가 비어 있습니다.");
    return;
  }

  const totalPrice = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  
  // 영수증 표시
  const receiptContainer = document.getElementById("receipt-container");
  receiptContainer.innerHTML = `
    <h3>영수증</h3>
    <ul>
      ${cartItems.map(item => `<li>${item.name} x ${item.quantity} - ${item.price * item.quantity}원</li>`).join('')}
    </ul>
    <p>총 금액: ${totalPrice}원</p>
  `;
  receiptContainer.style.display = 'block';

  // 판매 내역에 추가
  salesReport.push({
    items: cartItems.map(item => ({ name: item.name, price: item.price, quantity: item.quantity })),
    total: totalPrice,
    date: new Date().toLocaleString()
  });
  totalSales += totalPrice;

  // localStorage에 저장
  localStorage.setItem("salesReport", JSON.stringify(salesReport));
  localStorage.setItem("totalSales", totalSales);

  // 결제 후 장바구니 비우기
  cartItems = [];
  displayCart();
}

// 주문 초기화 함수
function resetOrder() {
  cartItems = [];
  document.getElementById("receipt-container").style.display = 'none';
  displayCart();
}

// 드래그 앤 드롭 기능 추가
function makeItemsDraggable() {
  const menuItems = document.querySelectorAll("#menu-container .item");
  menuItems.forEach(item => {
    item.setAttribute("draggable", "true");
    item.addEventListener("dragstart", dragStart);
  });
}

function dragStart(e) {
  e.dataTransfer.setData("text/plain", e.target.id);
}

function allowDrop(e) {
  e.preventDefault();
}

function drop(e) {
  e.preventDefault();
  const itemId = e.dataTransfer.getData("text/plain");
  const item = menuItems.find(menu => menu.id == itemId);
  addToCart(item.id);
}

function makeCartDroppable() {
  const cartContainer = document.getElementById("cart-container");
  cartContainer.addEventListener("dragover", allowDrop);
  cartContainer.addEventListener("drop", drop);
}

// 페이지가 로드되었을 때 메뉴 표시 및 드래그 앤 드롭 기능 활성화
window.onload = () => {
  displayMenu();
  makeItemsDraggable();
  makeCartDroppable();
};

// 관리자 페이지 이동 시 패스워드 확인
document.getElementById('admin-button').onclick = () => {
  document.getElementById('password-modal').style.display = 'block';
};

function closePasswordModal() {
  document.getElementById('password-modal').style.display = 'none';
}

function checkPassword() {
  const password = document.getElementById('admin-password').value;
  if (password === '0000') {
    location.href = 'admin.html';
  } else {
    alert('비밀번호가 잘못되었습니다.');
  }
}
